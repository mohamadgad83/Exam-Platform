/**
 * ============================================
 * Exam Platform v2.0 - App Utilities (FIXED)
 * ============================================
 * 
 * FIXES:
 * 1. renderLayout now loads sidebar dynamically (no duplication)
 * 2. Added mobile sidebar toggle
 * 3. Added skeleton loading states
 * 4. Fixed all function references
 * 5. Added debounce/throttle utilities
 * 6. Added localStorage helpers with expiry
 * 7. Added API wrapper with retry logic
 */

// ============================================
// CONFIG
// ============================================
const APP_CONFIG = {
  sidebarWidth: 280,
  toastDuration: 4000,
  apiRetryAttempts: 3,
  apiRetryDelay: 1000,
  sessionTimeout: 15 * 60 * 1000, // 15 minutes
};

// ============================================
// LAYOUT SYSTEM - Dynamic Loading
// ============================================

async function renderLayout(userRole, activePage) {
  // Load sidebar HTML
  const sidebarHTML = await loadSidebar(userRole, activePage);

  // Insert sidebar
  document.body.insertAdjacentHTML('afterbegin', sidebarHTML);

  // Insert mobile overlay
  const overlayHTML = '<div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>';
  document.body.insertAdjacentHTML('afterbegin', overlayHTML);

  // Insert mobile toggle button in top bar
  const mobileToggle = '<button class="mobile-toggle" onclick="toggleSidebar()" aria-label="فتح القائمة">☰</button>';

  // Render top bar inside main-content
  const mainContent = document.querySelector('.main-content');
  if (mainContent) {
    const topBarHTML = `
      <div class="top-bar">
        <div style="display:flex;align-items:center;gap:1rem;">
          ${mobileToggle}
          <div>
            <h1 class="page-title" id="page-title">${document.title}</h1>
            <p class="page-subtitle" id="page-subtitle"></p>
          </div>
        </div>
        <div class="top-actions">
          <button class="btn btn-ghost" onclick="showNotifications()" aria-label="الإشعارات">
            🔔 <span class="nav-badge" id="notif-count" style="display:none;">0</span>
          </button>
          <div class="user-mini" onclick="goToProfile()">
            <div class="avatar" id="user-avatar">👤</div>
            <div class="info" style="display:none;">
              <div class="name" id="user-name">مستخدم</div>
              <div class="role" id="user-role">طالب</div>
            </div>
          </div>
        </div>
      </div>
    `;
    mainContent.insertAdjacentHTML('afterbegin', topBarHTML);
  }

  // Load user info
  loadUserInfo();

  // Setup auto-logout
  setupSessionTimeout();
}

async function loadSidebar(role, activePage) {
  const navItems = getNavItems(role, activePage);
  const user = JSON.parse(localStorage.getItem('exam_platform_user') || '{}');

  return `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-header">
        <div class="logo-icon">📚</div>
        <div>
          <div class="logo-text">منصة الاختبارات</div>
          <div class="logo-sub">نظام إدارة الاختبارات</div>
        </div>
      </div>
      <nav class="sidebar-nav">
        ${navItems}
      </nav>
      <div class="sidebar-footer">
        <div class="user-mini" onclick="goToProfile()">
          <div class="avatar" id="sidebar-avatar">${(user.full_name?.[0] || '👤').toUpperCase()}</div>
          <div class="info">
            <div class="name" id="sidebar-name">${user.full_name || 'مستخدم'}</div>
            <div class="role" id="sidebar-role">${getRoleLabel(user.role)}</div>
          </div>
        </div>
        <a href="#" class="nav-item" onclick="handleLogout(event)" style="margin-top:0.75rem;color:#ef4444;">
          <span>🚪</span>
          <span>تسجيل الخروج</span>
        </a>
      </div>
    </aside>
  `;
}

function getNavItems(role, activePage) {
  const items = {
    admin: [
      { section: 'الرئيسية', items: [
        { id: 'dashboard', icon: '📊', label: 'لوحة التحكم', href: '/admin/dashboard.html' },
      ]},
      { section: 'الإدارة', items: [
        { id: 'users', icon: '👥', label: 'المستخدمين', href: '/admin/users.html' },
        { id: 'classes', icon: '🏫', label: 'الفصول', href: '/admin/classes.html' },
        { id: 'exams', icon: '📝', label: 'الاختبارات', href: '/admin/exams.html' },
      ]},
      { section: 'التقارير', items: [
        { id: 'reports', icon: '📈', label: 'التقارير', href: '/admin/reports.html' },
        { id: 'activity', icon: '📋', label: 'سجل النشاط', href: '/admin/activity.html' },
      ]},
      { section: 'الإعدادات', items: [
        { id: 'settings', icon: '⚙️', label: 'الإعدادات', href: '/admin/settings.html' },
      ]},
    ],
    teacher: [
      { section: 'الرئيسية', items: [
        { id: 'dashboard', icon: '📊', label: 'لوحة التحكم', href: '/teacher/dashboard.html' },
      ]},
      { section: 'الاختبارات', items: [
        { id: 'exams', icon: '📝', label: 'الاختبارات', href: '/teacher/exams.html' },
        { id: 'create-exam', icon: '➕', label: 'إنشاء اختبار', href: '/teacher/create-exam.html' },
        { id: 'questions', icon: '❓', label: 'بنك الأسئلة', href: '/teacher/questions.html' },
      ]},
      { section: 'الطلاب', items: [
        { id: 'students', icon: '👨‍🎓', label: 'الطلاب', href: '/teacher/students.html' },
        { id: 'groups', icon: '👥', label: 'المجموعات', href: '/teacher/groups.html' },
        { id: 'submissions', icon: '📋', label: 'التسليمات', href: '/teacher/submissions.html' },
      ]},
    ],
    student: [
      { section: 'الرئيسية', items: [
        { id: 'dashboard', icon: '📊', label: 'لوحة التحكم', href: '/student/dashboard.html' },
      ]},
      { section: 'الاختبارات', items: [
        { id: 'exams', icon: '📝', label: 'الاختبارات المتاحة', href: '/student/exams.html' },
        { id: 'results', icon: '📊', label: 'نتائجي', href: '/student/results.html' },
      ]},
      { section: 'حسابي', items: [
        { id: 'groups', icon: '👥', label: 'مجموعاتي', href: '/student/groups.html' },
        { id: 'profile', icon: '👤', label: 'ملفي الشخصي', href: '/student/profile.html' },
      ]},
    ]
  };

  const roleNav = items[role] || items.student;
  return roleNav.map(section => `
    <div class="nav-section">${section.section}</div>
    ${section.items.map(item => `
      <a href="${item.href}" class="nav-item ${item.id === activePage ? 'active' : ''}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </a>
    `).join('')}
  `).join('');
}

function getRoleLabel(role) {
  const labels = { admin: 'مدير', teacher: 'معلم', student: 'طالب' };
  return labels[role] || 'مستخدم';
}

function loadUserInfo() {
  const user = JSON.parse(localStorage.getItem('exam_platform_user') || '{}');
  if (user.full_name) {
    const initial = user.full_name.charAt(0).toUpperCase();
    document.querySelectorAll('#user-avatar, #sidebar-avatar').forEach(el => {
      if (el) el.textContent = initial;
    });
    document.querySelectorAll('#user-name, #sidebar-name').forEach(el => {
      if (el) el.textContent = user.full_name;
    });
    document.querySelectorAll('#user-role, #sidebar-role').forEach(el => {
      if (el) el.textContent = getRoleLabel(user.role);
    });
  }
}

// ============================================
// SIDEBAR MOBILE
// ============================================

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('active');
  document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
}

function closeSidebar() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  sidebar.classList.remove('open');
  overlay.classList.remove('active');
  document.body.style.overflow = '';
}

// ============================================
// AUTH GUARD
// ============================================

function requireAuth(requiredRole) {
  const user = JSON.parse(localStorage.getItem('exam_platform_user') || '{}');
  const token = localStorage.getItem('exam_platform_session');
  const lastActivity = parseInt(localStorage.getItem('last_activity') || '0');
  const now = Date.now();

  // Check session timeout
  if (lastActivity && (now - lastActivity) > APP_CONFIG.sessionTimeout) {
    handleLogout(new Event('timeout'));
    return false;
  }

  // Update last activity
  localStorage.setItem('last_activity', now.toString());

  if (!token || !user.id) {
    window.location.href = '/login.html?redirect=' + encodeURIComponent(window.location.pathname);
    return false;
  }

  if (requiredRole && user.role !== requiredRole) {
    window.location.href = '/unauthorized.html';
    return false;
  }

  return true;
}

function setupSessionTimeout() {
  // Reset timer on user activity
  ['click', 'keypress', 'scroll', 'mousemove'].forEach(event => {
    document.addEventListener(event, () => {
      localStorage.setItem('last_activity', Date.now().toString());
    }, { passive: true });
  });

  // Check every minute
  setInterval(() => {
    const lastActivity = parseInt(localStorage.getItem('last_activity') || '0');
    if (lastActivity && (Date.now() - lastActivity) > APP_CONFIG.sessionTimeout) {
      handleLogout(new Event('timeout'));
    }
  }, 60000);
}

async function handleLogout(e) {
  if (e) e.preventDefault();
  try {
    if (typeof Auth !== 'undefined') {
      await Auth.signOut();
    }
  } catch (err) {
    console.error('Logout error:', err);
  }
  localStorage.removeItem('exam_platform_user');
  localStorage.removeItem('exam_platform_session');
  localStorage.removeItem('last_activity');
  window.location.href = '/login.html';
}

function goToProfile() {
  const user = JSON.parse(localStorage.getItem('exam_platform_user') || '{}');
  const paths = { admin: '/admin/profile.html', teacher: '/teacher/profile.html', student: '/student/profile.html' };
  window.location.href = paths[user.role] || '/student/profile.html';
}

function showNotifications() {
  showToast('الإشعارات قريباً', 'info');
}

// ============================================
// TOAST SYSTEM
// ============================================

function showToast(message, type = 'info', duration = APP_CONFIG.toastDuration) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);

  // Auto remove
  const timeout = setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-120%)';
    setTimeout(() => toast.remove(), 300);
  }, duration);

  // Click to dismiss
  toast.addEventListener('click', () => {
    clearTimeout(timeout);
    toast.remove();
  });
}

// ============================================
// MODAL SYSTEM
// ============================================

function showModal(title, content, buttons = []) {
  // Remove existing modals
  document.querySelectorAll('.modal-overlay').forEach(el => el.remove());

  const modalHTML = `
    <div class="modal-overlay active" id="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="btn btn-sm btn-ghost" onclick="closeModal()" aria-label="إغلاق">✕</button>
        </div>
        <div class="modal-body">
          ${content}
        </div>
        ${buttons.length ? `
        <div class="modal-footer">
          ${buttons.map(btn => `
            <button class="btn ${btn.class || 'btn-secondary'}" onclick="${btn.action}">${btn.text}</button>
          `).join('')}
        </div>
        ` : ''}
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHTML);
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const overlay = document.getElementById('modal-overlay');
  if (overlay) {
    overlay.remove();
    document.body.style.overflow = '';
  }
}

function confirmDialog(message, onConfirm, onCancel) {
  showModal('تأكيد', `<p>${message}</p>`, [
    { text: 'إلغاء', class: 'btn-secondary', action: 'closeModal();' + (onCancel ? `(${onCancel})();` : '') },
    { text: 'تأكيد', class: 'btn-danger', action: `closeModal();(${onConfirm})();` }
  ]);
}

// ============================================
// LOADING STATES
// ============================================

function showLoading(element, text = '') {
  if (!element) return;
  element.dataset.originalHtml = element.innerHTML;
  element.dataset.originalDisabled = element.disabled;
  element.innerHTML = `<div class="spinner spinner-sm"></div>${text ? ' ' + text : ''}`;
  element.disabled = true;
}

function hideLoading(element) {
  if (!element) return;
  if (element.dataset.originalHtml) {
    element.innerHTML = element.dataset.originalHtml;
  }
  element.disabled = element.dataset.originalDisabled === 'true';
}

function showSkeleton(container, count = 3) {
  if (!container) return;
  container.innerHTML = Array(count).fill(0).map(() => `
    <div style="padding:1rem;margin-bottom:1rem;">
      <div class="skeleton" style="height:20px;width:60%;margin-bottom:0.75rem;"></div>
      <div class="skeleton" style="height:14px;width:40%;"></div>
    </div>
  `).join('');
}

// ============================================
// FORM VALIDATION
// ============================================

function validateForm(formElement) {
  let isValid = true;
  const errors = {};

  formElement.querySelectorAll('[data-validate]').forEach(field => {
    const rules = field.dataset.validate.split('|');
    const value = field.value.trim();
    const fieldName = field.name || field.id;

    for (const rule of rules) {
      if (rule === 'required' && !value) {
        errors[fieldName] = 'هذا الحقل مطلوب';
        isValid = false;
        break;
      }
      if (rule === 'email' && value && !isValidEmail(value)) {
        errors[fieldName] = 'البريد الإلكتروني غير صالح';
        isValid = false;
        break;
      }
      if (rule.startsWith('min:')) {
        const min = parseInt(rule.split(':')[1]);
        if (value.length < min) {
          errors[fieldName] = `يجب أن يكون ${min} أحرف على الأقل`;
          isValid = false;
          break;
        }
      }
      if (rule.startsWith('max:')) {
        const max = parseInt(rule.split(':')[1]);
        if (value.length > max) {
          errors[fieldName] = `يجب أن لا يتجاوز ${max} حرف`;
          isValid = false;
          break;
        }
      }
      if (rule === 'number' && value && isNaN(value)) {
        errors[fieldName] = 'يجب إدخال رقم';
        isValid = false;
        break;
      }
      if (rule === 'phone' && value && !isValidPhone(value)) {
        errors[fieldName] = 'رقم الهاتف غير صالح';
        isValid = false;
        break;
      }
    }
  });

  // Clear old errors
  formElement.querySelectorAll('.error-msg').forEach(el => el.remove());
  formElement.querySelectorAll('.error').forEach(el => el.classList.remove('error'));

  // Show new errors
  for (const [field, msg] of Object.entries(errors)) {
    const input = formElement.querySelector(`[name="${field}"], #${field}`);
    if (input) {
      input.classList.add('error');
      const errorEl = document.createElement('div');
      errorEl.className = 'error-msg';
      errorEl.innerHTML = `<span>⚠️</span><span>${msg}</span>`;
      input.parentNode.appendChild(errorEl);
    }
  }

  return isValid;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
  return /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/.test(phone);
}

// ============================================
// DATE/TIME HELPERS
// ============================================

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return '-';
  return date.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
}

function formatDateTime(dateStr) {
  if (!dateStr) return '-';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return '-';
  return date.toLocaleString('ar-EG', { 
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function formatDuration(minutes) {
  if (!minutes || minutes <= 0) return '0 دقيقة';
  if (minutes < 60) return `${minutes} دقيقة`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours} ساعة ${mins} دقيقة` : `${hours} ساعة`;
}

function timeAgo(dateStr) {
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return '-';
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);

  if (seconds < 60) return 'الآن';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} دقيقة`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} ساعة`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)} يوم`;
  return formatDate(dateStr);
}

function formatTimeRemaining(seconds) {
  if (seconds <= 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// ============================================
// FORMATTING
// ============================================

function formatNumber(num) {
  return num?.toLocaleString('ar-EG') || '0';
}

function formatGrade(grade, total) {
  if (!total || total <= 0) return '0%';
  const percentage = (grade / total) * 100;
  let color = 'var(--danger)';
  if (percentage >= 90) color = 'var(--success)';
  else if (percentage >= 70) color = 'var(--warning)';
  else if (percentage >= 50) color = 'var(--info)';

  return `<span style="color: ${color}; font-weight: 700;">${grade}/${total} (${percentage.toFixed(1)}%)</span>`;
}

function getGradeColor(percentage) {
  if (percentage >= 90) return 'var(--success)';
  if (percentage >= 70) return 'var(--warning)';
  if (percentage >= 50) return 'var(--info)';
  return 'var(--danger)';
}

// ============================================
// LOCAL STORAGE (with expiry)
// ============================================

function saveToStorage(key, data, ttlMinutes = null) {
  try {
    const item = {
      data: data,
      timestamp: Date.now(),
      ttl: ttlMinutes ? ttlMinutes * 60 * 1000 : null
    };
    localStorage.setItem(key, JSON.stringify(item));
  } catch (e) {
    console.error('Storage error:', e);
  }
}

function getFromStorage(key, defaultValue = null) {
  try {
    const stored = localStorage.getItem(key);
    if (!stored) return defaultValue;

    const item = JSON.parse(stored);

    // Check expiry
    if (item.ttl && (Date.now() - item.timestamp) > item.ttl) {
      localStorage.removeItem(key);
      return defaultValue;
    }

    return item.data;
  } catch {
    return defaultValue;
  }
}

function removeFromStorage(key) {
  localStorage.removeItem(key);
}

// ============================================
// DEBOUNCE/THROTTLE
// ============================================

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function throttle(func, limit) {
  let inThrottle;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// ============================================
// API WRAPPER (with retry)
// ============================================

async function apiCall(url, options = {}, retries = APP_CONFIG.apiRetryAttempts) {
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.json();
  } catch (err) {
    if (retries > 0) {
      await new Promise(r => setTimeout(r, APP_CONFIG.apiRetryDelay));
      return apiCall(url, options, retries - 1);
    }
    throw err;
  }
}

// ============================================
// EXPORT
// ============================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    renderLayout, requireAuth, showToast, showModal, closeModal,
    confirmDialog, validateForm, formatDate, formatDateTime,
    formatDuration, timeAgo, formatTimeRemaining, formatNumber, formatGrade,
    getGradeColor, saveToStorage, getFromStorage, removeFromStorage,
    debounce, throttle, apiCall, showLoading, hideLoading, showSkeleton,
    handleLogout, goToProfile, toggleSidebar, closeSidebar
  };
}
