/**
 * ============================================
 * Exam Platform - Secure Supabase Client
 * ============================================
 * 
 * ⚠️ IMPORTANT SECURITY NOTES:
 * 1. The Anon Key is safe to expose ONLY if RLS is enabled on ALL tables
 * 2. NEVER expose the Service Role Key in client-side code
 * 3. Always enable RLS policies before production
 * 4. For production, consider using Supabase Edge Functions for sensitive ops
 * 
 * RLS Policies Required:
 * - users: read own, admin read all
 * - exams: teacher read own, student read assigned, admin read all
 * - questions: teacher read own, student read during exam
 * - submissions: student read own, teacher read own students, admin read all
 * - groups: members read, admin/teacher read own
 */

const SUPABASE_URL = 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key-here';

let supabaseClient = null;
let currentUser = null;
let currentSession = null;

/**
 * Initialize Supabase client
 */
function initSupabase() {
  if (typeof supabase === 'undefined') {
    console.error('❌ Supabase library not loaded. Add: <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>');
    return null;
  }

  supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
      storage: window.localStorage,
      storageKey: 'exam_platform_session'
    },
    db: {
      schema: 'public'
    },
    global: {
      headers: {
        'X-Client-Info': 'exam-platform-k12'
      }
    }
  });

  return supabaseClient;
}

/**
 * Get Supabase client (singleton)
 */
function getSupabase() {
  if (!supabaseClient) {
    initSupabase();
  }
  return supabaseClient;
}

/**
 * Authentication Helpers
 */
const Auth = {
  async signUp(email, password, userData) {
    const { data, error } = await getSupabase().auth.signUp({
      email,
      password,
      options: { data: userData }
    });
    if (error) throw error;
    return data;
  },

  async signIn(email, password) {
    const { data, error } = await getSupabase().auth.signInWithPassword({
      email,
      password
    });
    if (error) throw error;
    currentSession = data.session;
    currentUser = data.user;
    return data;
  },

  async signOut() {
    const { error } = await getSupabase().auth.signOut();
    if (error) throw error;
    currentSession = null;
    currentUser = null;
    localStorage.removeItem('exam_platform_session');
    localStorage.removeItem('exam_platform_user');
  },

  async getSession() {
    const { data, error } = await getSupabase().auth.getSession();
    if (error) throw error;
    currentSession = data.session;
    return data.session;
  },

  async getUser() {
    if (currentUser) return currentUser;
    const { data, error } = await getSupabase().auth.getUser();
    if (error) throw error;
    currentUser = data.user;
    return data.user;
  },

  onAuthStateChange(callback) {
    return getSupabase().auth.onAuthStateChange((event, session) => {
      currentSession = session;
      if (session?.user) currentUser = session.user;
      callback(event, session);
    });
  },

  async resetPassword(email) {
    const { data, error } = await getSupabase().auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + '/reset-password.html'
    });
    if (error) throw error;
    return data;
  },

  async updatePassword(newPassword) {
    const { data, error } = await getSupabase().auth.updateUser({
      password: newPassword
    });
    if (error) throw error;
    return data;
  }
};

/**
 * Database Helpers with Validation
 */
const DB = {
  // Users
  async getUserProfile(userId) {
    const { data, error } = await getSupabase()
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    if (error) throw error;
    return data;
  },

  async updateUserProfile(userId, updates) {
    // Validation
    if (updates.email && !isValidEmail(updates.email)) {
      throw new Error('البريد الإلكتروني غير صالح');
    }
    if (updates.phone && !isValidPhone(updates.phone)) {
      throw new Error('رقم الهاتف غير صالح');
    }

    const { data, error } = await getSupabase()
      .from('users')
      .update(updates)
      .eq('id', userId)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getUsersByRole(role, filters = {}) {
    let query = getSupabase()
      .from('users')
      .select('*')
      .eq('role', role);

    if (filters.status) query = query.eq('status', filters.status);
    if (filters.search) query = query.ilike('full_name', `%${filters.search}%`);
    if (filters.class_id) query = query.eq('class_id', filters.class_id);

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  // Exams
  async getExams(filters = {}) {
    let query = getSupabase()
      .from('exams')
      .select('*, subjects(name), exam_schedules(*)');

    if (filters.teacher_id) query = query.eq('teacher_id', filters.teacher_id);
    if (filters.status) query = query.eq('status', filters.status);
    if (filters.subject_id) query = query.eq('subject_id', filters.subject_id);
    if (filters.search) query = query.ilike('title', `%${filters.search}%`);

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getExamById(examId) {
    const { data, error } = await getSupabase()
      .from('exams')
      .select('*, subjects(name), exam_questions(question:questions(*))')
      .eq('id', examId)
      .single();
    if (error) throw error;
    return data;
  },

  async createExam(examData) {
    // Validation
    if (!examData.title?.trim()) throw new Error('عنوان الامتحان مطلوب');
    if (!examData.subject_id) throw new Error('المادة مطلوبة');
    if (!examData.duration || examData.duration < 5) throw new Error('مدة الامتحان يجب أن تكون 5 دقائق على الأقل');
    if (!examData.total_marks || examData.total_marks <= 0) throw new Error('الدرجات الكلية مطلوبة');
    if (!examData.questions || examData.questions.length === 0) throw new Error('يجب إضافة أسئلة للامتحان');

    const { data, error } = await getSupabase()
      .from('exams')
      .insert(examData)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateExam(examId, updates) {
    const { data, error } = await getSupabase()
      .from('exams')
      .update(updates)
      .eq('id', examId)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteExam(examId) {
    // Check if exam has submissions first
    const { count, error: countError } = await getSupabase()
      .from('submissions')
      .select('*', { count: 'exact', head: true })
      .eq('exam_id', examId);

    if (countError) throw countError;
    if (count > 0) throw new Error('لا يمكن حذف الامتحان لوجود تسليمات');

    const { error } = await getSupabase()
      .from('exams')
      .delete()
      .eq('id', examId);
    if (error) throw error;
  },

  // Questions
  async getQuestions(filters = {}) {
    let query = getSupabase()
      .from('questions')
      .select('*, subjects(name), users(full_name)');

    if (filters.teacher_id) query = query.eq('teacher_id', filters.teacher_id);
    if (filters.subject_id) query = query.eq('subject_id', filters.subject_id);
    if (filters.type) query = query.eq('type', filters.type);
    if (filters.search) query = query.ilike('question_text', `%${filters.search}%`);
    if (filters.difficulty) query = query.eq('difficulty', filters.difficulty);

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createQuestion(questionData) {
    if (!questionData.question_text?.trim()) throw new Error('نص السؤال مطلوب');
    if (!questionData.type) throw new Error('نوع السؤال مطلوب');
    if (!questionData.correct_answer) throw new Error('الإجابة الصحيحة مطلوبة');
    if (questionData.type === 'mcq' && (!questionData.options || questionData.options.length < 2)) {
      throw new Error('يجب إضافة خيارين على الأقل للسؤال الاختياري');
    }

    const { data, error } = await getSupabase()
      .from('questions')
      .insert(questionData)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Submissions
  async getSubmissions(filters = {}) {
    let query = getSupabase()
      .from('submissions')
      .select('*, exams(title, duration), users(full_name, email)');

    if (filters.student_id) query = query.eq('student_id', filters.student_id);
    if (filters.exam_id) query = query.eq('exam_id', filters.exam_id);
    if (filters.teacher_id) query = query.eq('exams.teacher_id', filters.teacher_id);

    const { data, error } = await query.order('submitted_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getSubmissionById(submissionId) {
    const { data, error } = await getSupabase()
      .from('submissions')
      .select('*, exams(*, questions(*)), student_answers_detailed(*)')
      .eq('id', submissionId)
      .single();
    if (error) throw error;
    return data;
  },

  async submitExam(submissionData) {
    if (!submissionData.exam_id) throw new Error('معرف الامتحان مطلوب');
    if (!submissionData.student_id) throw new Error('معرف الطالب مطلوب');
    if (!submissionData.answers || Object.keys(submissionData.answers).length === 0) {
      throw new Error('يجب الإجابة على الأسئلة');
    }

    const { data, error } = await getSupabase()
      .from('submissions')
      .insert(submissionData)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Groups
  async getGroups(filters = {}) {
    let query = getSupabase()
      .from('groups')
      .select('*, group_students(student:users(*))');

    if (filters.teacher_id) query = query.eq('teacher_id', filters.teacher_id);
    if (filters.search) query = query.ilike('name', `%${filters.search}%`);

    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  // Notifications
  async getNotifications(userId, limit = 20) {
    const { data, error } = await getSupabase()
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) throw error;
    return data || [];
  },

  async markNotificationRead(notificationId) {
    const { error } = await getSupabase()
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);
    if (error) throw error;
  },

  // Activity Log
  async logActivity(activity) {
    const { error } = await getSupabase()
      .from('activity_log')
      .insert({
        user_id: activity.user_id,
        action: activity.action,
        details: activity.details,
        ip_address: activity.ip || 'unknown',
        user_agent: navigator.userAgent,
        created_at: new Date().toISOString()
      });
    if (error) console.error('Activity log error:', error);
  },

  // Real-time subscriptions
  subscribeToNotifications(userId, callback) {
    return getSupabase()
      .channel('notifications')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` },
        callback
      )
      .subscribe();
  },

  subscribeToExamChanges(callback) {
    return getSupabase()
      .channel('exams')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'exams' },
        callback
      )
      .subscribe();
  }
};

/**
 * Storage Helpers
 */
const Storage = {
  async uploadFile(bucket, path, file) {
    const { data, error } = await getSupabase()
      .storage
      .from(bucket)
      .upload(path, file, { upsert: true });
    if (error) throw error;
    return data;
  },

  async getPublicUrl(bucket, path) {
    const { data } = getSupabase()
      .storage
      .from(bucket)
      .getPublicUrl(path);
    return data.publicUrl;
  },

  async deleteFile(bucket, path) {
    const { error } = await getSupabase()
      .storage
      .from(bucket)
      .remove([path]);
    if (error) throw error;
  }
};

/**
 * Validation Helpers
 */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
  return /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/.test(phone);
}

function sanitizeInput(input) {
  if (typeof input !== 'string') return input;
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Export for module usage
 */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { getSupabase, Auth, DB, Storage, initSupabase, sanitizeInput };
}
